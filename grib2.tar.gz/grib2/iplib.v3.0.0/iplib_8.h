#ifndef IPLIB
#define IPLIB

void gdswzd(long *kgds, long iopt, long npts, double fill,
            double *xpts, double *ypts, double *rlon, double *rlat,
            long *nret,
            double *crot, double *srot, double *xlon, double *xlat,
            double *ylon, double *ylat, double *area);

#endif
