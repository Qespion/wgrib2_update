#ifndef IPLIB
#define IPLIB

void gdswzd(int *kgds, int iopt, int npts, double fill,
            double *xpts, double *ypts, double *rlon, double *rlat,
            int *nret,
            double *crot, double *srot, double *xlon, double *xlat,
            double *ylon, double *ylat, double *area);

#endif
